@echo off
setlocal
where codex.cmd >nul 2>nul
if errorlevel 1 (
  echo Codex CLI nao encontrado no PATH. Abra um novo terminal e confira a instalacao existente.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Preparar-REA-Studio.ps1"
if errorlevel 1 (
  echo Falha na preparacao. Codex nao sera iniciado.
  pause
  exit /b 1
)
cd /d "%LOCALAPPDATA%\REA-Studio\Workspace"
if errorlevel 1 exit /b 1
call codex.cmd --sandbox workspace-write --add-dir "%USERPROFILE%\Documents\REA_Relatorios"
endlocal
