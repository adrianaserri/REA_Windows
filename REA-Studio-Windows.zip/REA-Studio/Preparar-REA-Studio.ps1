﻿# Kit em Program Files; dados graváveis no perfil do usuário.
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) { throw 'LOCALAPPDATA não definido.' }
$project = Join-Path $env:LOCALAPPDATA 'REA-Studio\Workspace'
New-Item -ItemType Directory -Path $project -Force | Out-Null
foreach ($dir in @('amostras')) {
    New-Item -ItemType Directory -Path (Join-Path $project $dir) -Force | Out-Null
}
# Cria somente quando ausente; preserva a pasta e os arquivos existentes.
$reports = Join-Path $env:USERPROFILE 'Documents\REA_Relatorios'
if (-not (Test-Path -LiteralPath $reports -PathType Container)) {
    New-Item -ItemType Directory -Path $reports -Force -ErrorAction Stop | Out-Null
}
foreach ($name in @('AGENTS.md','LEIA-ME.md','PROMPTS.txt','Diagnostico-REA-Studio.ps1')) {
    $source = Join-Path $PSScriptRoot $name
    $dest = Join-Path $project $name
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw ('Arquivo ausente: ' + $source) }
    if ([IO.Path]::GetFullPath($source) -eq [IO.Path]::GetFullPath($dest)) { continue }
    if (Test-Path -LiteralPath $dest) {
        $same = (Get-FileHash -LiteralPath $source).Hash -eq (Get-FileHash -LiteralPath $dest).Hash
        if ($same) { continue }
        $backup = $dest + '.backup-' + [Guid]::NewGuid().ToString('N')
        Copy-Item -LiteralPath $dest -Destination $backup -ErrorAction Stop
        Write-Host ('Cópia anterior preservada: ' + $backup)
    }
    Copy-Item -LiteralPath $source -Destination $dest -Force -ErrorAction Stop
}
Write-Host ('Pasta de trabalho: ' + $project)
Write-Host ('Relatórios: ' + $reports)
Write-Host 'Preparação concluída. Nenhum software instalado ou configuração MCP alterada.'
