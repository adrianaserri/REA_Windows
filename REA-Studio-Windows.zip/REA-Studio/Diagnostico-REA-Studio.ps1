﻿# Diagnóstico de ambiente REA Studio — não instala, atualiza ou analisa amostras.
$ErrorActionPreference = 'Stop'
$lines = New-Object 'System.Collections.Generic.List[string]'
function Add-Line([string]$s) { $lines.Add($s); Write-Host $s }
function Which([string[]]$names) {
    foreach ($name in $names) {
        $found = Get-Command -Name $name -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($null -ne $found) { return $found }
    }
    return $null
}
function Check-Tool([string]$label, [string[]]$names, [string[]]$arguments) {
    $c = Which $names
    if ($null -eq $c) { Add-Line ('[AUSENTE NO PATH] ' + $label); return $null }
    Add-Line ('[ENCONTRADO] ' + $label + ' => ' + $c.Source)
    if ($arguments.Count -gt 0) {
        try {
            # Windows PowerShell 5.1 trata stderr nativo como ErrorRecord.
            $oldPreference = $ErrorActionPreference
            try {
                $ErrorActionPreference = 'Continue'
                $result = & $c.Source @arguments 2>&1 | Out-String
                $toolExit = $LASTEXITCODE
            } finally { $ErrorActionPreference = $oldPreference }
            Add-Line ('  Código de saída: ' + $toolExit)
            $result = $result.Trim()
            if ($result.Length -gt 800) { $result = $result.Substring(0,800) + '... [truncado]' }
            if ($result) { Add-Line ('  ' + $result.Replace("`r", '').Replace("`n", "`n  ")) }
        } catch { Add-Line ('  [NÃO CONFIRMADO] ' + $_.Exception.Message) }
    }
    return $c
}
function Env-Check([string]$name) {
    $value = [Environment]::GetEnvironmentVariable($name, 'Process')
    if ([string]::IsNullOrWhiteSpace($value)) { $value = [Environment]::GetEnvironmentVariable($name, 'User') }
    if ([string]::IsNullOrWhiteSpace($value)) { $value = [Environment]::GetEnvironmentVariable($name, 'Machine') }
    if ([string]::IsNullOrWhiteSpace($value)) {
        Add-Line ('[NÃO DEFINIDO] ' + $name + ' — pode ter sido configurado só na sessão anterior')
        return $null
    }
    Add-Line ('[DEFINIDO] ' + $name + ' = ' + $value)
    if (Test-Path -LiteralPath $value -PathType Container) { Add-Line '  Diretório existe.' }
    else { Add-Line '  [ATENÇÃO] Diretório inexistente neste Windows.' }
    return $value
}
Add-Line '=== REA STUDIO: DIAGNÓSTICO LOCAL ==='
Add-Line ('Data: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
Add-Line ('PowerShell: ' + $PSVersionTable.PSVersion.ToString())
Add-Line ('Windows x64: ' + [Environment]::Is64BitOperatingSystem)
Add-Line '--- Ferramentas ---'
$codex = Check-Tool 'Codex' @('codex.cmd','codex.exe','codex') @('--version')
$node = Check-Tool 'Node.js' @('node.exe','node') @('--version')
$npm = Check-Tool 'npm' @('npm.cmd','npm') @('--version')
$npx = Which @('npx.cmd','npx')
if ($null -ne $npx) { Add-Line ('[ENCONTRADO] npx => ' + $npx.Source) }
else { Add-Line '[AUSENTE NO PATH] npx' }
$rea = Check-Tool 'REA CLI (opcional)' @('rea.cmd','rea.exe','rea') @('--version')
$java = Check-Tool 'Java runtime' @('java.exe','java') @('-version')
$javac = Check-Tool 'Java compiler' @('javac.exe','javac') @('-version')
Add-Line '--- Variáveis de ambiente ---'
$jhome = Env-Check 'JAVA_HOME'
$ghidra = Env-Check 'GHIDRA_INSTALL_DIR'
if ($ghidra -and (Test-Path -LiteralPath $ghidra -PathType Container)) {
    $runner = Join-Path $ghidra 'ghidraRun.bat'
    $headless = Join-Path $ghidra 'support\analyzeHeadless.bat'
    Add-Line ('Ghidra launcher: ' + (Test-Path -LiteralPath $runner -PathType Leaf))
    Add-Line ('Ghidra headless: ' + (Test-Path -LiteralPath $headless -PathType Leaf))
}
Add-Line '--- Registro MCP do Codex ---'
$codexHome = $env:CODEX_HOME
if ([string]::IsNullOrWhiteSpace($codexHome)) { $codexHome = Join-Path $env:USERPROFILE '.codex' }
$config = Join-Path $codexHome 'config.toml'
if (Test-Path -LiteralPath $config -PathType Leaf) {
    Add-Line ('[EXISTE] ' + $config)
    try {
        $raw = Get-Content -LiteralPath $config -Raw -ErrorAction Stop
        if ($raw -match '(?m)^\s*\[mcp_servers\.rea\]\s*$') { Add-Line '[ENCONTRADO] seção [mcp_servers.rea]' }
        else { Add-Line '[NÃO ENCONTRADO] seção [mcp_servers.rea] (pode haver outro nome de servidor)' }
    } catch { Add-Line '[NÃO FOI POSSÍVEL LER] config.toml' }
} else { Add-Line ('[NÃO ENCONTRADO] ' + $config) }
if ($null -ne $codex) {
    try {
        Add-Line 'Saída de codex mcp list:'
         $oldPreference = $ErrorActionPreference
        try {
            $ErrorActionPreference = 'Continue'
            $mcpOut = & $codex.Source mcp list 2>&1 | Out-String
            $mcpExit = $LASTEXITCODE
        } finally { $ErrorActionPreference = $oldPreference }
        Add-Line ('Código de saída de mcp list: ' + $mcpExit)
        if ($mcpOut.Length -gt 2000) { $mcpOut = $mcpOut.Substring(0,2000) + '... [truncado]' }
        Add-Line $mcpOut.Trim()
    } catch { Add-Line ('[NÃO CONFIRMADO] codex mcp list: ' + $_.Exception.Message) }
}
Add-Line '--- Observações ---'
Add-Line 'Este script NÃO executa o REA doctor nem inicia análise de arquivos.'
Add-Line 'A presença de registro MCP não prova que a conexão ou o provedor estejam saudáveis.'
Add-Line 'Use o teste de conexão do PROMPTS.txt no Codex local.'
try {
    $outDir = Join-Path $env:USERPROFILE 'Documents\REA_Relatorios'
    if (-not (Test-Path -LiteralPath $outDir -PathType Container)) {
        New-Item -ItemType Directory -Path $outDir -Force -ErrorAction Stop | Out-Null
    }
    $report = Join-Path $outDir ('diagnostico-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '-' + [Guid]::NewGuid().ToString('N') + '.txt')
    $lines | Set-Content -LiteralPath $report -Encoding UTF8 -ErrorAction Stop
    Add-Line ('Relatório salvo em: ' + $report)
    Add-Line 'Revise nomes de usuário e caminhos antes de compartilhar o relatório.'
} catch { Add-Line ('FALHA ao salvar relatório: ' + $_.Exception.Message); exit 1 }
