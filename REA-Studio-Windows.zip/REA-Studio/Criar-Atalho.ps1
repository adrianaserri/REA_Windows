﻿$ErrorActionPreference = 'Stop'
$launcher = Join-Path $PSScriptRoot 'Abrir-Codex-CLI.cmd'
if (-not (Test-Path -LiteralPath $launcher -PathType Leaf)) { throw 'Launcher ausente.' }
$desktop = [Environment]::GetFolderPath('DesktopDirectory')
if ([string]::IsNullOrWhiteSpace($desktop)) { throw 'Área de trabalho não localizada.' }
$link = Join-Path $desktop 'REA Studio - Codex.lnk'
if (Test-Path -LiteralPath $link) { throw ('Atalho já existe: ' + $link + '. Renomeie-o antes de criar outro.') }
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($link)
$shortcut.TargetPath = $launcher
$shortcut.WorkingDirectory = $PSScriptRoot
$shortcut.Description = 'Abre Codex na área de trabalho REA do usuário'
$shortcut.Save()
Write-Host ('Atalho criado: ' + $link)
