# REA Studio — pacote corrigido, revisão 4

## Local do kit e dos dados
Extraia a pasta REA-Studio em **Arquivos de Programas** pelo Explorador.
No Windows em português, essa pasta geralmente corresponde a `C:\Program Files`.
Use a pasta que o Explorador já mostra: não crie outra pasta chamada Arquivos de Programas na raiz.
O Windows pode pedir autorização de administrador somente para copiar o kit ali.
Não execute Codex como administrador e não altere as permissões dessa pasta.

O kit fica em Program Files, mas a área de trabalho gravável fica em:
`%LOCALAPPDATA%\REA-Studio\Workspace`
Normalmente: `C:\Users\Admin\AppData\Local\REA-Studio\Workspace`.
Amostras ficam na subpasta `amostras` dessa área.
Relatórios ficam em `%USERPROFILE%\Documents\REA_Relatorios`.
Para Admin: `C:\Users\Admin\Documents\REA_Relatorios`.
O caminho usa o perfil de quem abriu o programa; em outro usuário, não depende de Admin.
É o caminho literal Documents, mesmo se Documentos estiver redirecionado ao OneDrive.
A preparação cria a pasta se ausente e prossegue se já existir, sem apagar seu conteúdo.
O launcher usa `--sandbox workspace-write` e `--add-dir` para incluir somente essa pasta adicional nas áreas de escrita
do Codex, sujeito às políticas ativas; não altera ACLs nem a configuração global.
Relatórios antigos na subpasta `Workspace\relatorios` permanecem onde estavam.
O ZIP pode ficar guardado como backup; não é executado pelo launcher.

## Abrir
Dê dois cliques em `Abrir-Codex-CLI.cmd` na pasta instalada.
Ele prepara a área do usuário e abre o Codex nela. Não instala nada, não muda
JAVA_HOME, PATH nem MCP. As ferramentas existentes continuam dependendo de sua configuração atual.
Arquivos de controle diferentes são atualizados com backup da cópia anterior;
amostras e relatórios existentes não são substituídos.
Dados de uma pasta antiga não são migrados automaticamente: copie seus arquivos
manualmente para a nova área, se houver.

## Atalho opcional
Abra PowerShell normal na pasta instalada e execute:
```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Criar-Atalho.ps1
```
O atalho aponta para o launcher. Depois de criá-lo, mantenha o kit nesse local.

## Diagnóstico
Na pasta instalada ou na área de trabalho preparada:
```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Diagnostico-REA-Studio.ps1
```
O diagnóstico verifica comandos, variáveis, arquivos básicos do Ghidra e registro
MCP. Não instala nada, não abre amostras e não comprova comunicação MCP nem
saúde do descompilador. Use o teste de conexão de PROMPTS.txt dentro do Codex.
Só anuncia relatório salvo se a gravação tiver sucesso; falha de gravação retorna código 1.
Se o registro MCP contiver caminhos absolutos para Downloads, a movimentação
pode exigir ajuste posterior. Este pacote não altera esse registro automaticamente.

## Limites da revisão
Scripts revisados e pacote conferido em Linux; execução real em Windows,
atalho COM, JDK, Ghidra e comunicação REA precisam ser validados no seu computador.
Não reinstale ferramentas apenas por mover o kit.

## Atualizar esta revisão
Feche a sessão do Codex. Extraia o ZIP e copie os arquivos da pasta REA-Studio
para a pasta instalada em Arquivos de Programas, substituindo os arquivos do kit.
Depois abra Abrir-Codex-CLI.cmd novamente. O atalho existente continua funcionando
se o local do kit não mudar. Não copie amostras ou relatórios sobre outros arquivos.

## Criar a pasta manualmente (opcional)
O launcher já faz isso. Em PowerShell, o comando equivalente é:
```powershell
$destino = Join-Path $env:USERPROFILE 'Documents\REA_Relatorios'
if (-not (Test-Path -LiteralPath $destino -PathType Container)) {
    New-Item -ItemType Directory -Path $destino -Force -ErrorAction Stop | Out-Null
}
```
Se houver erro de acesso ou um arquivo com esse nome, a preparação para e informa
o erro; não declara sucesso nem abre o Codex. Não execute como administrador.
